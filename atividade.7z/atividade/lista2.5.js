//Array de 10 elementos
//Acrescente elementos na array até o a array ficar com 10
//elementos. (usando while ou for).
var prompt = require('prompt-sync')();
let letras = []
let alfa 
while(letras.length <=10){
     alfa = prompt("Digite uma letra: ")
letras.push(alfa)
    
    
}
    console.log("FIM");
    