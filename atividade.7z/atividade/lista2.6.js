//Somando valores de um vetor
//Crie um vetor com 5 números e mostre no console a soma
//total desses valores.
let numeros = [1,4,6,8,10]
let soma = 0
for(let i = 0 ; i < numeros.length ; i++){
    soma= soma + numeros[i]
}
console.log(soma);
