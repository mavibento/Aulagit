//Vetor de cores
//Crie um vetor com 3 cores.
//Depois:
// Adicione uma cor no final com push();
//Remova a primeira com shift();
//Exiba o vetor final no console.
let cores = [ "azul","roxo","verde" ]
cores.push("vermelho")
console.log(cores);
cores.shift(cores)
console.log(cores)

