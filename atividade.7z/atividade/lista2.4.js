//O fim da array
//Acrescente elementos na array até o usuário escrever "fim"
var prompt = require('prompt-sync')();
let cor = ["azul","verde","preto"]
let adc 
while(adc != "fim"){


     adc = prompt("adicione uma cor:")

        cor.push(adc)
        console.log(cor);
    
    }
    console.log("Programa finalizado!!!");
        

    

 
    

   

    