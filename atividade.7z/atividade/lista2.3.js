//Array de números
//Crie um array com 5 números inteiros e exiba no console.
let numeros = [1, 2, 45, 90, 200]
console.log(numeros);
